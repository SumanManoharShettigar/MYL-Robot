
import java.time.LocalTime
import java.util.*


class Robot {

    var days = listOf<String>("Sunday", "Saturday")
    var activeDays = mutableListOf(0, 0, 0, 0, 0, 0, 0)
    var arr: MutableList<Int> = mutableListOf()
    var wakeUpTimeHr: Int? = null
    var wakeUpTimeMin: Int? = null
    var coffeeTimeHr : Int? = null
    var coffeeTimeMin : Int? = null
    var coffeeType : String? = null
    var coffeeSugar : Float? = null
    var breakfast : MutableList<String?> = mutableListOf()
    var lunch : MutableList<String?> = mutableListOf()
    var lunchHr : Int? = null
    var lunchMin : Int? = null
    var breakfastHr : Int? = null
    var breakfatsMin : Int? = null
    var upperWear : String? = null
    var lowerWear : String? = null
    var timeTablelist: MutableList<String?> = mutableListOf()
    var waterTimeHr :Int? = null
    var waterTimeMin : Int? = null
    var waterTemp : Float? = null
    var occ6 = 0
    var occ5 = 0
    var occ4 = 0
    var occ3 = 0
    var occ2 = 0
    var occ1 = 0


    fun alarmDays() {
        var count = 0
        println("Enter the days when you want the alarm to be active\n1.Sunday\n2.Monday\n3.Tuesday\n4.Wednesday\n5.Thursday\n6.Friday\n7.Saturday")
        println("(Press q to accept)")
        while (true) {
            var ch: String = readLine()!!
            if (ch == "q") {
                println("Active Days are Set")
                break
            }
            count++
            if (count == 7) {
                break
            }
            arr.add(ch.toInt())


        }

        for (element in arr) {
            activeDays[element - 1] = 1

        }

    }

    fun alarm() {
        alarmDays()
        println("Enter the Wake Up Hour : (24 Hours Format)")
        wakeUpTimeHr = readLine()!!.toInt()
        println("Enter the Wake Up Minute :")
        wakeUpTimeMin = readLine()!!.toInt()
        println("Alarm is Set.")
    }

    fun coffee(){
        println("When would you like to have Coffee?\n 1.Hour?")
        coffeeTimeHr = readLine()?.toInt()
        println("Minute?")
        coffeeTimeMin = readLine()?.toInt()
        println("How do you like your coffee (Black/With Milk) ?")
        coffeeType = readLine()
        println("How much sugar you’ll take ? (in grams)")
        coffeeSugar = readLine()?.toFloat()
        println("Coffee timer is set.")

    }
    fun selectfood(){
        println("Enter your favourite breakfast : (Press q to Accept)")
        while(true){
            var ch = readLine()
            if(ch == "q"){
                break
            }
            breakfast.add(ch)
        }
        println("Enter your favourite lunch : (Press q to Accept)")
        while(true){
            var ch = readLine()
            if(ch == "q"){
                break
            }
            lunch.add(ch)
        }
    }

    fun foodTime(){
        println("Enter the time for Breakfast\nHour : ")
        breakfastHr = readLine()?.toInt()
        println("Minute : ")
        breakfatsMin = readLine()?.toInt()
        println("Breakfast is set.")
        println("Enter the time for Lunch\nHour : ")
        lunchHr = readLine()?.toInt()
        println("Minute : ")
        lunchMin = readLine()?.toInt()
        println("Lunch is Set.")

    }
    fun clothing(){
        println("What would you like to wear today ?\nUpperWear : ")
        upperWear = readLine()
        println("Lowerwear : ")
        lowerWear = readLine()

    }
    fun clothReady(){
        println("Your $upperWear and $lowerWear are ready!!")

    }
    fun timeTable() {
        println("Enter your Time Table :(Press Q to Accept)")
        while (true){
            var ch = readLine()
            if (ch == "q"){
                println("Timetable is set.")
                break}
            timeTablelist.add(ch)

        }

    }

    fun timeTableRun() {
        println("Your books as per your timetable is set")
        println(timeTablelist)
    }

    fun heatWater(){
        println("Temperature at which water should be heated (Celcius): ")
        waterTemp = readLine()?.toFloat()
        println("Enter the time to heat the water : ")
        println("Hour : ")
        waterTimeHr = readLine()!!.toInt()
        println("Minute : ")
        waterTimeMin = readLine()!!.toInt()
        println("Water Heater is set.")
    }




    fun Run(): Boolean {

        if (activeDays[Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1] == 1) {
            if (LocalTime.now().hour == wakeUpTimeHr && LocalTime.now().minute == wakeUpTimeMin && occ1 == 0) {
                println("Good Morning , Sunshine Wake Up ")
                occ1 = 1
            }
        }

        if (LocalTime.now().hour == waterTimeHr && LocalTime.now().minute == waterTimeMin && occ2 == 0) {
            println("Water has been heated at $waterTemp Celcius")
            occ2 = 1
            clothing()
            clothReady()

        }

        if (LocalTime.now().hour == coffeeTimeHr && LocalTime.now().minute == coffeeTimeMin && occ3 == 0) {
            println("Your $coffeeType Coffee with $coffeeSugar g sugar is ready!!")
            occ3 = 1
            if (occ6 == 0 && !(timeTablelist.isEmpty())){
                timeTableRun()
                occ6 = 1
            }
        }

        if (LocalTime.now().hour == breakfastHr && LocalTime.now().minute == breakfatsMin && occ4 == 0){
            println("Your ${breakfast.random()} is ready!!}")
            occ4 = 1

        }

        if (LocalTime.now().hour == lunchHr && LocalTime.now().minute == lunchMin && occ5 == 0){
            println("Your ${lunch.random()} is ready!!")
            occ5 =1
        }

        if (wakeUpTimeHr == null && coffeeTimeHr == null && wakeUpTimeHr ==null && breakfastHr == null && lunchHr == null) {
            return true
        }
        return false





    }
}









fun main(){
    var MYL = Robot()
    while(true){
        println("Select Option to Set\n1.Alarm\n2.Pack Bag\n3.Heat Water\n4.Breakfast & Lunch\n5.Coffee\n(Press 0 to Start the ROBOT)")
        var ch = readLine()?.toInt()
        if (ch == 0){
            println("ROBOT has Started!!")
            break
            }
        when(ch){
            1 -> {
                   MYL.alarm()
                 }
            2 -> MYL.timeTable()

            3 -> MYL.heatWater()

            4 -> {
                MYL.selectfood()
                MYL.foodTime()
               }

            5 -> {
                MYL.coffee()
                }
        }
    }
    while(true) {
        if(MYL.Run()){
            println("No Options selected")
            break
        }



    }




}